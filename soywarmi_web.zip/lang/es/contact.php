<?php

return [
    'title_contact' => 'Contáctanos!',
    'your_name' => 'Tu nombre...',
    'your_email' => 'Tu correo...',
    'your_message' => 'Tu mensaje...*',
    'subject' => 'Asunto...',
    'send' => 'Enviar mensaje ahora',
    'phone_number' => 'Números de teléfono',
    'email' => 'Correo',
    'social_networks' => 'Redes sociales',
    'follow_facebook' => 'Síganos en Facebook',
    'follow_instagram' => 'Síganos en Instagram',
    'follow_tiktok' => 'Síganos en TikTok',
    'back_to_home' => 'Volver a la página de inicio',
];
