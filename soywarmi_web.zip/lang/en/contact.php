<?php

return [
    'title_contact' => 'Contact Us!',
    'your_name' => 'Your Name...',
    'your_email' => 'Your Email...',
    'your_message' => 'Your Message...*',
    'subject' => 'Subject...',
    'send' => 'Send message now',
    'phone_number' => 'Phone numbers',
    'email' => 'Email',
    'social_networks' => 'Social Networks',
    'follow_facebook' => 'Follow us on Facebook',
    'follow_instagram' => 'Follow us on Instagram',
    'follow_tiktok' => 'Follow us on TikTok',
    'back_to_home' => 'Back to Home',
];
