<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="heading-page header-text" id="top">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 style="text-transform: none; color: white">SoyWarmi</h2>
                </div>
            </div>
        </div>
    </section>

    <section class="meetings-page" id="meetings" style="padding-top: 10px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="meeting-single-item">
                        <div class="down-content" style="border-radius: 20px;">
                            <h4 class="stylea"><?php echo e(__('ourmission.about_us')); ?></h4>
                            <p class="description" style="margin-top: 10px; margin-bottom: 0; padding-bottom: 0;">
                                <?php echo e(__('ourmission.description_us')); ?></p>
                            <button class="btn btn-danger animated flash" style="margin-top: 4px; border-radius: 12px;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round">
                                    <circle cx="12" cy="12" r="10" />
                                    <path d="M12 8l4 4-4 4M8 12h7" />
                                </svg>
                                Programas y Proyectos
                            </button>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 d-flex align-items-center">
                    <div class="meeting-single-item">
                        <div class="down-content" style="border-radius: 20px;">
                            <img src="<?php echo e(asset('assets/images/logohorizontal.png')); ?>">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col">
                    <div class="meeting-single-item">
                        <div class="down-content" style="border-radius: 5%;">
                            <h4 class="stylea"><?php echo e(__('ourmission.tittle_history_us')); ?></h4>
                            <p class="description" style="margin-top: 10px; margin-bottom: 0; padding-bottom: 0;">
                                <?php echo e(__('ourmission.history_us')); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col d-flex align-items-center">
                    <div class="meeting-single-item">
                        <div class="down-content" style="border-radius: 20px;">
                            <div class="video w-50">
                                
                                <iframe width="560" height="315"
                                    src="https://www.youtube.com/embed/efiYGs8wBOg?si=amFObweIWnPYfudx"
                                    title="YouTube video player" frameborder="0"
                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                    allowfullscreen></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-lg-4 d-flex align-items-center">
                    <div class="meeting-single-item">
                        <div class="down-content" style="border-radius: 20px;">
                            <img src="<?php echo e(asset('assets/images/warmi_ambassors2.jpg')); ?>">
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="meeting-single-item">
                        <div class="down-content" style="border-radius: 20px;">
                            <h4 class="stylea"><?php echo e(__('ourmission.tittle_why_us')); ?></h4>
                            <p class="description" style="margin-top: 10px; margin-bottom: 0; padding-bottom: 0;">
                                <?php echo e(__('ourmission.why_us')); ?></p>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <section class="our-courses" id="courses">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-heading">
                        <h2><?php echo e(__('home.teamTittle')); ?>&nbsp;😊</h2>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="owl-courses-item owl-carousel">
                        <?php
                        $arrayColores = [
                        'F2AE5D',
                        '8B3A3D',
                        '00858E'
                        ];
                        ?>
                        <?php $__empty_1 = true; $__currentLoopData = $teams[0]->person; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                        $color = $arrayColores[rand(0, 2)];
                        ?>
                        <div class="item">
                            <img src="<?php echo e(env('API_URL_API') . $personas->photo); ?>" style="border-width: 0 5px 5px 5px; border-style: solid; border-radius: 20px 20px 0 0; border-color: #<?php echo e($color); ?>;
                                alt=" Course One">
                            <div class="down-content"
                                style="border-width: 0 5px 5px 5px; border-style: solid; border-radius: 0 0 20px 20px; border-color: #<?php echo e($color); ?>;">
                                <h4><?php echo e($personas->description); ?></h4>
                                <div class="info">
                                    <div class="row">
                                        <div class="col">
                                            <span><?php echo e($personas->name . " " . $personas->lastname); ?></span>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No hay equipo
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\soywarmi_web\resources\views/our-mission.blade.php ENDPATH**/ ?>