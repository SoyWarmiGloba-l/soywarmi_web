<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- ***** Main Banner Area Start ***** -->
    <section class="section main-banner" id="top" data-section="section1">
        <!-- <video autoplay muted loop id="bg-video">
          <source src="assets/images/course-video.mp4" type="video/mp4" />
      </video> -->
        <img id="bg-video" src="<?php echo e(asset('assets/images/soywarmiall.png')); ?>" alt="">
        <?php if (isset($component)) { $__componentOriginal54867e81c853e2fcebe2d39548be5889 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal54867e81c853e2fcebe2d39548be5889 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.modalSubcribe','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.modalSubcribe'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal54867e81c853e2fcebe2d39548be5889)): ?>
<?php $attributes = $__attributesOriginal54867e81c853e2fcebe2d39548be5889; ?>
<?php unset($__attributesOriginal54867e81c853e2fcebe2d39548be5889); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal54867e81c853e2fcebe2d39548be5889)): ?>
<?php $component = $__componentOriginal54867e81c853e2fcebe2d39548be5889; ?>
<?php unset($__componentOriginal54867e81c853e2fcebe2d39548be5889); ?>
<?php endif; ?>
        <div class="video-overlay header-text">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="caption">
                            <div class="main-button-red mb-4 animated flash">
                                <div>
                                    <a href="<?php echo e(route('our-mission')); ?>">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round">
                                            <circle cx="12" cy="12" r="10" />
                                            <path d="M12 8l4 4-4 4M8 12h7" />
                                        </svg>
                                        <?php echo e(__('home.mission')); ?>

                                    </a>
                                </div>
                            </div>
                            <h6></h6>
                            <h2><?php echo e(__('home.welcome')); ?></h2>
                            <p><?php echo e(__('home.resum')); ?></p>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Main Banner Area End ***** -->

    <section class="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="owl-service-item owl-carousel">

                        <div class="item">
                            <div class="icon">
                                <img src="assets/images/service-icon-01.png" alt="">
                            </div>
                            <div class="down-content">
                                <h4><?php echo e(__('home.bestproyect')); ?></h4>
                                <p><?php echo e(__('home.bestproyectdescription')); ?></p>
                            </div>
                        </div>

                        <a href="https://www.worldlearning.org" target="_blank">
                            <div class="item">
                                <div class="icon">
                                    <img src="assets/images/service-icon-02.png" alt="">
                                </div>

                                <div class="down-content">
                                    <h4>World Learning.</h4>
                                    <p><?php echo e(__('home.impulsing')); ?></p>
                                </div>

                            </div>
                        </a>
                        <a href="https://thepollinationproject.org" target="_blank">
                            <div class="item">
                                <div class="icon">
                                    <img src="assets/images/service-icon-02.png" alt="">
                                </div>
                                <div class="down-content">
                                    <h4>The Pollination Project.</h4>
                                    <p><?php echo e(__('home.bestpopulationproyect')); ?></p>
                                </div>
                            </div>
                        </a>
                        <a href="https://www.unesco.org" target="_blank">
                            <div class="item">
                                <div class="icon">
                                    <img src="assets/images/service-icon-03.png" alt="">
                                </div>
                                <div class="down-content">
                                    <h4><?php echo e(__('home.bestparticipating')); ?></h4>
                                    <p><?php echo e(__('home.bestparticipatingdescription')); ?></p>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="upcoming-meetings" id="meetings">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-heading">
                        <h2><?php echo e(__('home.whyus')); ?></h2>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="categories" style="border-width: 5px; border-style: solid; border-color: #00858E;">
                        <h4><?php echo e(__('home.whyus1')); ?></h4>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="categories" style="border-width: 5px; border-style: solid; border-color: #F2AE5D;">
                        <h4><?php echo e(__('home.whyus2')); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section class="our-facts" style="padding-top: 10px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2><?php echo e(__('home.smallus')); ?></h2>
                        </div>
                        <div class="col-lg-6">
                            <div class="row">
                                <div class="col-12">
                                    <div class="count-area-content">
                                        <div class="count-digit" style="color: #00858E">70</div>
                                        <div class="count-title"><?php echo e(__('home.countPerson')); ?></div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="count-area-content">
                                        <div class="count-digit" style="color: #8B3A3D">500</div>
                                        <div class="count-title"><?php echo e(__('home.countWork')); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row">
                                <div class="col-12">
                                    <div class="count-area-content new-students">
                                        <div class="count-digit" style="color: #F2AE5D">10</div>
                                        <div class="count-title"><?php echo e(__('home.countEducation')); ?></div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="count-area-content">
                                        <div class="count-digit" style="color: #A9CDDB">150</div>
                                        <div class="count-title"><?php echo e(__('home.countVoluntary')); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 align-self-center">
                    <div class="video">
                        
                        <iframe width="560" height="315"
                            src="https://www.youtube.com/embed/efiYGs8wBOg?si=amFObweIWnPYfudx"
                            title="YouTube video player" frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen></iframe>
                    </div>
                    <div style="text-align: center; padding-left: 200px;">
                        <div class="main-button-red mb-4 animated flash">
                            <div>
                                <a href="<?php echo e(route('our-mission')); ?>">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"
                                        fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round">
                                        <circle cx="12" cy="12" r="10" />
                                        <path d="M12 8l4 4-4 4M8 12h7" />
                                    </svg>
                                    <?php echo e(__('home.donation')); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="apply-now" id="apply">
        <div class="container text-center">
            <div class="row">
                <div class="col-12">
                    <div class="main-button-red mb-4">
                        <a href="#">
                            Ver más Noticias
                        </a>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 align-self-center">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="item">
                                <h3><?php echo e($news1->title); ?></h3>
                                <p><?php echo e(Str::limit($news1->description, 120)); ?></p>
                                <div class="main-button-red">
                                    <div class="scroll-to-section"><a href="#contact">Leer más-></a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="item">
                                <h3><?php echo e($news2->title); ?></h3>
                                <p><?php echo e(Str::limit($news2->description, 120)); ?></p>
                                <div class="main-button-yellow">
                                    <div class="scroll-to-section"><a href="#contact">Leer más-></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="accordions is-first-expanded"
                        style="border-width: 5px; border-style: solid; border-color: #8B3A3D;">
                        <?php $__empty_1 = true; $__currentLoopData = $otherNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <article class="accordion <?php if($loop->last): ?> last-accordion <?php endif; ?>">
                            <div class="accordion-head">
                                <span><?php echo e($new->title); ?></span>
                                <span class="icon">
                                    <i class="icon fa fa-chevron-right"></i>
                                </span>
                            </div>
                            <div class="accordion-body">
                                <div class="content">
                                    <p><?php echo e(Str::limit($new->description, 120)); ?></p>
                                </div>
                            </div>
                        </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <article class="accordion">
                            <div class="accordion-head">
                                <span>No News</span>
                                <span class="icon">
                                    <i class="icon fa fa-chevron-right"></i>
                                </span>
                            </div>
                            <div class="accordion-body">
                                <div class="content">
                                    <p>No News</p>
                                </div>
                            </div>
                        </article>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="our-courses" id="courses" style="padding-top: 10px; padding-bottom: 0px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-heading">
                        <a href="<?php echo e(route('testimony')); ?>">
                            <h2><?php echo e(__('home.alltestimony')); ?>👈</h2>
                        </a>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="owl-courses-item owl-carousel">
                        <?php $__empty_1 = true; $__currentLoopData = $testimonies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimony): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="item">
                            <?php
                            $arrayColores = [
                            'F2AE5D',
                            '8B3A3D',
                            '00858E'
                            ];
                            ?>
                            <a href="<?php echo e(route('testimony.show', $testimony->slug)); ?>" target="_blank">
                                <div class="down-content"
                                    style="border-width: 5px; border-style: solid; border-radius: 20px; border-color: #<?php echo e($arrayColores[rand(0, 2)]); ?>;">
                                    <h4><?php echo e($testimony->person->name); ?></h4>
                                    <div class="info">
                                        <div class="row">
                                            <div class="col-12" style="word-break: break-all;">
                                                <p><?php echo e(Str::limit($testimony->description, 100, '...')); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No hay
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="apply-now" id="apply">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 align-self-center">
                    <div class="row">
                        <div class="col-md-6">
                            
                            <style>
                                .carousel {
                                    border-radius: 20px;
                                    overflow: hidden;
                                }
                            </style>
                            <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
                                <div class="carousel-indicators">
                                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0"
                                        class="active" aria-current="true" aria-label="Slide 1"></button>
                                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                                        aria-label="Slide 2"></button>
                                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                                        aria-label="Slide 3"></button>
                                </div>
                                <div class="carousel-inner">
                                    <div class="carousel-item active rounded-4">
                                        <img src="<?php echo e(asset('assets/images/Group 11 (1).png')); ?>" class="d-block w-100"
                                            alt="...">
                                        <div class="carousel-caption d-none d-md-block">
                                            <h5>Reporte</h5>
                                            <p>La Paz</p>
                                        </div>
                                    </div>
                                    <div class="carousel-item">
                                        <img src="<?php echo e(asset('assets/images/course-02.jpg')); ?>" class="d-block w-100"
                                            alt="...">
                                        <div class="carousel-caption d-none d-md-block">
                                            <h5>Second slide label</h5>
                                            <p>Some representative placeholder content for the second slide.</p>
                                        </div>
                                    </div>
                                    <div class="carousel-item">
                                        <img src="<?php echo e(asset('assets/images/course-03.jpg')); ?>" class="d-block w-100"
                                            alt="...">
                                        <div class="carousel-caption d-none d-md-block">
                                            <h5>Third slide label</h5>
                                            <p>Some representative placeholder content for the third slide.</p>
                                        </div>
                                    </div>
                                </div>
                                <button class="carousel-control-prev" type="button"
                                    data-bs-target="#carouselExampleCaptions" data-bs-target="#carouselExampleCaptions"
                                    data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Previous</span>
                                </button>
                                <button class="carousel-control-next" type="button"
                                    data-bs-target="#carouselExampleCaptions" data-bs-target="#carouselExampleCaptions"
                                    data-bs-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Next</span>
                                </button>
                            </div>
                        </div>
                        <div class="col-md-6">
                            
                            <style>
                                .carousel {
                                    border-radius: 20px;
                                    overflow: hidden;
                                }
                            </style>
                            <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
                                <div class="carousel-indicators">
                                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0"
                                        class="active" aria-current="true" aria-label="Slide 1"></button>
                                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                                        aria-label="Slide 2"></button>
                                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                                        aria-label="Slide 3"></button>
                                </div>
                                <div class="carousel-inner">
                                    <div class="carousel-item active rounded-4">
                                        <img src="<?php echo e(asset('assets/images/Group 11 (1).png')); ?>" class="d-block w-100"
                                            alt="...">
                                        <div class="carousel-caption d-none d-md-block">
                                            <h5>Reporte</h5>
                                            <p>La Paz</p>
                                        </div>
                                    </div>
                                    <div class="carousel-item">
                                        <img src="<?php echo e(asset('assets/images/course-02.jpg')); ?>" class="d-block w-100"
                                            alt="...">
                                        <div class="carousel-caption d-none d-md-block">
                                            <h5>Second slide label</h5>
                                            <p>Some representative placeholder content for the second slide.</p>
                                        </div>
                                    </div>
                                    <div class="carousel-item">
                                        <img src="<?php echo e(asset('assets/images/course-03.jpg')); ?>" class="d-block w-100"
                                            alt="...">
                                        <div class="carousel-caption d-none d-md-block">
                                            <h5>Third slide label</h5>
                                            <p>Some representative placeholder content for the third slide.</p>
                                        </div>
                                    </div>
                                </div>
                                <button class="carousel-control-prev" type="button"
                                    data-bs-target="#carouselExampleCaptions" data-bs-target="#carouselExampleCaptions"
                                    data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Previous</span>
                                </button>
                                <button class="carousel-control-next" type="button"
                                    data-bs-target="#carouselExampleCaptions" data-bs-target="#carouselExampleCaptions"
                                    data-bs-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Next</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php if (isset($component)) { $__componentOriginal3df85818993e3c6c4ff45791ace105e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3df85818993e3c6c4ff45791ace105e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.contact','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.contact'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3df85818993e3c6c4ff45791ace105e7)): ?>
<?php $attributes = $__attributesOriginal3df85818993e3c6c4ff45791ace105e7; ?>
<?php unset($__attributesOriginal3df85818993e3c6c4ff45791ace105e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3df85818993e3c6c4ff45791ace105e7)): ?>
<?php $component = $__componentOriginal3df85818993e3c6c4ff45791ace105e7; ?>
<?php unset($__componentOriginal3df85818993e3c6c4ff45791ace105e7); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\soywarmi_web\resources\views/home.blade.php ENDPATH**/ ?>