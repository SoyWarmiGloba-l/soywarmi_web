<!-- ***** Header Area Start ***** -->
<header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                    <a href="<?php echo e(route('home')); ?>" class="logo">
                        <img class="w-50 img-fluid" src="<?php echo e(asset('assets/images/logo_warmi.png')); ?>" />
                    </a>
                    <!-- ***** Logo End ***** -->
                    <!-- ***** Menu Start ***** -->
                    <ul class="nav">
                        
                        <li><a class="stylea" href="<?php echo e(route('projects_programs')); ?>">Programas</a></li>
                        <li><a class="styleaa" href="<?php echo e(route('resources')); ?>">Recursos</a></li>
                        <li class="scroll-to-section"><a href="#meetings">Nosotros</a></li>
                        <li class="scroll-to-section"><a class="styleaaa" href="#contact">Contact</a></li>
                        <li><a class="styleaaaa" href="https://linktr.ee/soywarmi" target="_blank">Postular</a>
                        </li>
                        <li class="has-sub">
                            <a href="javascript:void(0)">
                                <?php echo e(config('app.locale')); ?>

                            </a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo e(url('locale/en')); ?>">En</a></li>
                                <li><a href="<?php echo e(url('locale/es')); ?>">Es</a></li>
                            </ul>
                        </li>
                    </ul>
                    <a class='menu-trigger'>
                        <span>Menu</span>
                    </a>
                    <!-- ***** Menu End ***** -->
                </nav>
            </div>
        </div>
    </div>
</header>
<!-- ***** Header Area End ***** --><?php /**PATH C:\laragon\www\soywarmi_web\resources\views/components/layouts/navbar.blade.php ENDPATH**/ ?>