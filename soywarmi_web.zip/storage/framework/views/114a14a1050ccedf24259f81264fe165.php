<div class="footer contact-us">
    <p>Copyright © 2023 <span style="color: red;">SoyWarmi</span> All Rights Reserved.</p>
    
</div><?php /**PATH C:\laragon\www\soywarmi_web\resources\views/components/layouts/footer.blade.php ENDPATH**/ ?>