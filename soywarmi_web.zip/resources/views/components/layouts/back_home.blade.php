<div class="col-lg-12">
    <div class="main-button-red">
        <a href="{{ route('home') }}">{{ __('contact.back_to_home') }}</a>
    </div>
</div>
